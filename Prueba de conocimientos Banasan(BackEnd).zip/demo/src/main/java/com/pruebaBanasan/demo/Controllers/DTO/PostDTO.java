package com.pruebaBanasan.demo.Controllers.DTO;

import com.pruebaBanasan.demo.Models.UserEntity;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PostDTO {
    @NotBlank
    private String title;
    private String content;
    private int numberOfVotes = 0;
    private LocalDate creationDate = LocalDate.now();
    private UserEntity user;
}
