package com.pruebaBanasan.demo.Controllers;

import com.pruebaBanasan.demo.Controllers.DTO.PostDTO;
import com.pruebaBanasan.demo.Models.Post;
import com.pruebaBanasan.demo.Services.PostService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reedit.com")
public class PostController {

    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @PostMapping("/post/create")
    public ResponseEntity<?> createPost(@Valid @RequestBody PostDTO postDTO){
        return ResponseEntity.ok(postService.createPost(postDTO));
    }

    @PutMapping("/post/update")
    public ResponseEntity<?> updatePost(@RequestParam("postId") Long postId,@Valid @RequestBody PostDTO postDTO){
        return ResponseEntity.ok("Usuario actualizado");
    }

    @GetMapping("/posts")
    public List<Post> getAllPotsInOrderAsc(){
        return postService.getAllPotsInOrderAsc();
    }

    @PostMapping("/post/addUser")
    public Post addUserToPost(@RequestParam("postId") Long postId, @RequestParam("userId") Long userId){
        return postService.addUserToPost(postId,userId);
    }

    @PostMapping("/post/addVote")
    public String addVoteToPost(@RequestParam("postId") Long postId, @RequestParam("userId") Long usertId){
        return postService.addVoteToPost(postId, usertId);}
    }
