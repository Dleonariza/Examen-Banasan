package com.pruebaBanasan.demo.Controllers;

import com.pruebaBanasan.demo.Controllers.DTO.UserDTO;
import com.pruebaBanasan.demo.Models.UserEntity;
import com.pruebaBanasan.demo.Services.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/reedit.com")
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/user/create")
    public ResponseEntity<?> createUser(@Valid @RequestBody UserDTO userDTO){
        return ResponseEntity.ok(userService.createUser(userDTO));
    }

    @GetMapping("/users")
    public List<UserEntity> getAllUsers(){
        return userService.listAllUsers();
    }

    @GetMapping("/userById")
    public UserEntity getUserById(@RequestParam("userId") Long userId){
        return userService.findUserById(userId);
    }

    @DeleteMapping("/user/delete")
    public ResponseEntity<String> deleteUser(@RequestParam("userId") Long userId){
        userService.deleteUser(userId);
        return ResponseEntity.ok("Usuario eliminado de forma exitosa");
    }

    @PutMapping("/user/update")
    public ResponseEntity<?> updateUser(@RequestParam("userId") Long userId, @RequestBody UserDTO userDTO){
        return ResponseEntity.ok(userService.updateUser(userId,userDTO));
    }

}
