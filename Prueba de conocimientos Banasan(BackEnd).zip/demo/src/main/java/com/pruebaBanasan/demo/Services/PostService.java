package com.pruebaBanasan.demo.Services;

import com.pruebaBanasan.demo.Controllers.DTO.PostDTO;
import com.pruebaBanasan.demo.Repositories.PostRepository;
import com.pruebaBanasan.demo.Repositories.UserRepository;
import com.pruebaBanasan.demo.Models.Post;
import com.pruebaBanasan.demo.Models.UserEntity;
import org.springframework.stereotype.Service;


import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@Service
public class PostService {
    private final PostRepository postRepository;
    private final UserRepository userRepository;

    public PostService(PostRepository postRepository, UserRepository userRepository) {
        this.postRepository = postRepository;
        this.userRepository = userRepository;
    }

    public Post createPost(PostDTO postDTO){
        Post post = Post.builder()
                .content(postDTO.getContent())
                .creationDate(postDTO.getCreationDate())
                .title(postDTO.getTitle())
                .numberOfVotes(postDTO.getNumberOfVotes())
                .build();
        return postRepository.save(post);
    }

    public void deletePost(Long id){
        postRepository.deleteById(id);
    }

    public Post updatePost(Long id, PostDTO postDTO){
        Post olderPost = postRepository.potsById(id);
        String title = postDTO.getTitle();
        olderPost.setTitle(title);
        String content = postDTO.getContent();
        olderPost.setContent(content);
        LocalDate dateCreation = postDTO.getCreationDate();
        olderPost.setCreationDate(dateCreation);
        return postRepository.save(olderPost);
    }

    public List<Post> getAllPost(){
        return postRepository.findAll();
    }

    public List<Post> getAllPotsInOrderAsc(){
        return postRepository.getAllPotsInOrderAsc();
    }

    public String addVoteToPost(Long postId, Long userId){
        UserEntity user = userRepository.userID(userId);
        if(user.isVoted() == false){
            Post olderPost = postRepository.potsById(postId);
            int cant = olderPost.getNumberOfVotes();
            cant += 1;
            olderPost.setNumberOfVotes(cant);
            LocalDate datePost = olderPost.getCreationDate();
            olderPost.setCreationDate(datePost);
            postRepository.save(olderPost);
            user.setVoted(true);
            userRepository.save(user);
            return "Voto agregado";
        }
        return "El user ya ha votado esta publicacion";
    }

    public Post addUserToPost(Long postId, Long userId){
        Post olderPost = postRepository.potsById(postId);
        UserEntity user = userRepository.userID(userId);
        if(olderPost != null && user != null){
            olderPost.setUser(user);
            return postRepository.save(olderPost);
        }
        return null;
    }
}
