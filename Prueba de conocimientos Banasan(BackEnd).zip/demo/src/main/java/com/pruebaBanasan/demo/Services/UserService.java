package com.pruebaBanasan.demo.Services;

import com.pruebaBanasan.demo.Controllers.DTO.UserDTO;
import com.pruebaBanasan.demo.Models.Post;
import com.pruebaBanasan.demo.Models.UserEntity;
import com.pruebaBanasan.demo.Repositories.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public UserEntity createUser(UserDTO userDTO){
        UserEntity user = UserEntity.builder()
                .user_name(userDTO.getUser_name())
                .last_name(userDTO.getLast_name())
                .first_name(userDTO.getFirst_name())
                .email(userDTO.getEmail())
                .password(userDTO.getPassword())
                .pots(userDTO.getPots())
                .build();
        return userRepository.save(user);
    }

    public List<UserEntity> listAllUsers(){
        return userRepository.findAll();
    }

    public UserEntity findUserById(Long id){
        return userRepository.userID(id);
    }

    public void deleteUser(Long id){
        userRepository.deleteById(id);
    }

    public UserEntity updateUser(Long id, UserDTO userDTO){
        UserEntity user = userRepository.userID(id);
        String userName = userDTO.getUser_name();
        user.setUser_name(userName);
        String firstName = userDTO.getFirst_name();
        user.setFirst_name(firstName);
        String lastName = userDTO.getLast_name();
        user.setLast_name(lastName);
        String email = userDTO.getEmail();
        user.setEmail(email);
        String password = userDTO.getPassword();
        user.setPassword(password);
        Set<Post> posts = userDTO.getPots();
        user.setPots(posts);
        return userRepository.save(user);
    }

}
