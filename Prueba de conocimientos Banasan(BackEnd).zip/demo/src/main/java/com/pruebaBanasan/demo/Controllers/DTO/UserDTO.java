package com.pruebaBanasan.demo.Controllers.DTO;

import com.pruebaBanasan.demo.Models.Post;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO {
    @NotBlank
    private String user_name;
    @NotBlank
    private String first_name;
    @NotBlank
    private String last_name;
    @Email
    @NotBlank
    private String email;
    @NotBlank
    private String password;
    private Set<Post> pots;
}
